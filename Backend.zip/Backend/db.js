// const { Pool } = require("pg");
// const config = require("./config");

// // Database creation function
// const createDatabase = async () => {
//   const tempPool = new Pool({
//     user: config.database.user,
//     host: config.database.host,
//     database: "postgres",
//     password: config.database.password,
//     port: config.database.port,
//   });

//   try {
//     await tempPool.query(`CREATE DATABASE ${config.database.name}`);
//     console.log("Database created successfully");
//   } catch (error) {
//     if (error.code === "42P04") {
//       console.log("Database already exists");
//     } else {
//       console.error("Error creating database:", error);
//       process.exit(-1);
//     }
//   } finally {
//     await tempPool.end();
//   }
// };

// const getDatabasePool = () => {
//   return new Pool({
//     user: config.database.user,
//     host: config.database.host,
//     database: config.database.name,
//     password: config.database.password,
//     port: config.database.port,
//   });
// };

const { Pool } = require("pg");
 
// Use the DATABASE_URL environment variable
const DATABASE_URL = 'postgresql://neondb_owner:npg_0txfy1lzgULq@ep-bitter-sky-a1hogm2l-pooler.ap-southeast-1.aws.neon.tech/neondb?sslmode=require';
 
// Database creation function - Note: With Neon DB, database creation is typically done through their interface
const createDatabase = async () => {
  console.log("Database creation is managed through Neon DB interface");
};
 
const getDatabasePool = () => {
  return new Pool({
    connectionString: DATABASE_URL,
  });
};

// Table creation function
const createTable = async () => {
  const tempPool = getDatabasePool();

  const createUserTableQuery = `
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      user_name VARCHAR(50) NOT NULL,
      email VARCHAR(50) NOT NULL UNIQUE,
      phone_number CHAR(10) CHECK (phone_number ~ '^[0-9]{10}$'),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      house_name VARCHAR(255),
      location VARCHAR(100),
      user_info VARCHAR(100),
      user_image VARCHAR(255),
      jwt_token VARCHAR(255),
      uid VARCHAR(50) UNIQUE,
      login_status BOOLEAN DEFAULT FALSE
    );
  `;

  try {
    await tempPool.query(createUserTableQuery);
    console.log("Users table created successfully");
  } catch (error) {
    console.log("Error creating users table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};



// Function to create the images table
const createImagesTable = async () => {
  const tempPool = getDatabasePool();

  const createImagesTableQuery = `
      CREATE TABLE IF NOT EXISTS images (
        id SERIAL PRIMARY KEY,
        image_url VARCHAR(255)
      );
    `;

  try {
    await tempPool.query(createImagesTableQuery);
    console.log("Images table created successfully");
  } catch (error) {
    console.log("Error creating images table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};

//  admin_addon
const createFoodItemsTable = async () => {
  const tempPool = getDatabasePool();

  const createFoodItemsTableQuery = `
      CREATE TABLE IF NOT EXISTS admin_addon (
        id SERIAL PRIMARY KEY,
        status BOOLEAN,
        item_name VARCHAR(255),
        item_image VARCHAR(255),
        item_url VARCHAR(255),
        item_type VARCHAR(50),
        item_description VARCHAR(255),
        item_price NUMERIC(10, 2),
        item_qty INTEGER 
      );
    `;

  try {
    await tempPool.query(createFoodItemsTableQuery);
    console.log("Food items table created successfully");
  } catch (error) {
    console.log("Error creating food items table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};

// addon
const createAddonTable = async () => {
  const tempPool = getDatabasePool();

  const createAddonTableQuery = `
      CREATE TABLE IF NOT EXISTS addon (
        orderId VARCHAR(255) PRIMARY KEY,
        status BOOLEAN,
        uid VARCHAR(255),
        currentTime VARCHAR(50),
        totalPricePaid NUMERIC(10, 2),
        paymentMethod VARCHAR(255),
        types JSONB,
        userdata JSONB,
        qty INT,
        subTotal NUMERIC,
        gst NUMERIC, 
        deliveryCharge NUMERIC 
      );
    `;

  try {
    await tempPool.query(createAddonTableQuery);
    console.log("Addon table created successfully");
  } catch (error) {
    console.log("Error creating addon table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};

const createDeliveryTable = async () => {
  const tempPool = getDatabasePool();

  const createDeliveryTableQuery = `
    CREATE TABLE IF NOT EXISTS delivery (
      id SERIAL PRIMARY KEY,
      uid VARCHAR(255),
      route VARCHAR(255),
      deliveryuser VARCHAR(255),
      userdata JSONB,
      deliverydata JSONB,
      status BOOLEAN,
      order_id VARCHAR(255) UNIQUE
  );
    `;

  try {
    await tempPool.query(createDeliveryTableQuery);
    console.log("Delivery table created successfully");
  } catch (error) {
    console.log("Error creating delivery table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};


const createDeleteUserTable = async () => {
  const tempPool = getDatabasePool();

  const createDeleteUserTableQuery = `
      CREATE TABLE IF NOT EXISTS deleteuser (
        id SERIAL PRIMARY KEY,
        PhoneNumber VARCHAR(255) UNIQUE,
        FullName VARCHAR(255),
        Reason TEXT
      );
    `;

  try {
    await tempPool.query(createDeleteUserTableQuery);
    console.log("Deleteuser table created successfully");
  } catch (error) {
    console.log("Error creating deleteuser table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};
const createUpdatePushTable = async () => {
  const tempPool = getDatabasePool();

  const createUpdatePushTableQuery = `
    CREATE TABLE IF NOT EXISTS updatepush (
      alert_id VARCHAR(255) PRIMARY KEY,
      title VARCHAR(255),
      message TEXT,
      severity VARCHAR(50),
      timestamp TIMESTAMP,
      update_url VARCHAR(255),
      dismissable BOOLEAN
    );
  `;

  try {
    await tempPool.query(createUpdatePushTableQuery);
    console.log("UpdatePush table created successfully");
  } catch (error) {
    console.log("Error creating UpdatePush table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};

const UpdateRating = async () => {
  const tempPool = getDatabasePool();

  const createUpdateTableQuery = `
    CREATE TABLE IF NOT EXISTS rating (
      id SERIAL PRIMARY KEY,
      rating JSONB,
      status BOOLEAN DEFAULT TRUE
    );
  `;

  try {
    await tempPool.query(createUpdateTableQuery);
    console.log("Update rating table created successfully");
  } catch (error) {
    console.log("Error creating Update rating table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};
const createAddressTable = async () => {
  const tempPool = getDatabasePool();

  const createAddressTableQuery = `
CREATE TABLE IF NOT EXISTS address (
  id SERIAL PRIMARY KEY,
  uid UUID NOT NULL,
  phone_number VARCHAR(15) NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  location_map TEXT,
  home_flat VARCHAR(100),
  road_area VARCHAR(255),
  direction_reach VARCHAR(255),
  address_status BOOLEAN DEFAULT TRUE,
  save_as VARCHAR(50)
);

  
    `;

  try {
    await tempPool.query(createAddressTableQuery);
    console.log("Address table created successfully");
  } catch (error) {
    console.log("Error creating users table:", error);
    process.exit(-1);
  } finally {
    await tempPool.end();
  }
};
module.exports = {
  createDatabase,
  getDatabasePool,
  createTable,
  // createSetupMealsTable,
  createImagesTable,
  createFoodItemsTable,
  createAddonTable,
  createDeliveryTable,
  // createMenuTable,
  createDeleteUserTable,
  createUpdatePushTable,
  UpdateRating,
  createAddressTable,
};
