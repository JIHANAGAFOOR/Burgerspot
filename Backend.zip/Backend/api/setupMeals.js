// const express = require("express");
// const { getDatabasePool } = require("../db");
// const cron = require('node-cron');
// const router = express.Router();


// // Function to decrement noOfDays
// async function decrementNoOfDays() {
//     try {
//         const tempPool = getDatabasePool();
  
//         // Update query to decrement noOfDays by 1 for all records where noOfDays > 0
//         const updateQuery = `
//             UPDATE setupmeals
//             SET subscription_details = jsonb_set(subscription_details, '{noOfDays}', ((subscription_details->>'noOfDays')::int - 1)::TEXT::jsonb)
//             WHERE (subscription_details->>'noOfDays')::int > 0;
//         `;
  
//         // Execute the update query
//         await tempPool.query(updateQuery);
  
//         // Now, update the subscription_status to "end" where noOfDays is 0
//         const endSubscriptionQuery = `
//             UPDATE setupmeals
//             SET subscription_status = 'End'
//             WHERE (subscription_details->>'noOfDays')::int = 0;
//         `;
  
//         // Execute the query to update subscription_status
//         await tempPool.query(endSubscriptionQuery);
  
//         console.log("NoOfDays decremented successfully.");
//     } catch (error) {
//         console.error("Error decrementing noOfDays:", error);
//     }
//   }
  
  
//   // Schedule the decrementNoOfDays function to run every day at midnight in Kolkata timezone
//   cron.schedule('0 0 * * *', () => {
//     decrementNoOfDays();
//   }, {
//     timezone: "Asia/Kolkata"
//   });
  
//   // Schedule the decrementNoOfDays function to run every 10 seconds for testing
  
//   // cron.schedule('*/10 * * * * *', () => {
//   //   decrementNoOfDays();
//   // });
  
  
//   // create meals Mainapp
//   router.post("/createSetupMeals", async (req, res) => {
//     try {
//       const tempPool = getDatabasePool();
  
//       const { orderId, startDate, endDate, transactionId, currentTime, noOfDays, totalPricePaid, paymentMethod, totalPerDayCost, tokens, subscription_status, uid, order_status, subTotal, gst, deliveryCharge, userdata } = req.body;
  
//       try {
//         const result = await tempPool.query(
//           `
//           INSERT INTO setupmeals (orderId, subscription_status, uid, subscription_details, order_status, subTotal, gst, deliveryCharge, userdata)
//           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
//           ON CONFLICT (orderId) DO UPDATE 
//           SET subscription_status = $2, uid = $3, subscription_details = $4, order_status = $5, subTotal = $6, gst = $7, deliveryCharge = $8, userdata = $9
//           RETURNING *;
//           `,
//           [orderId, subscription_status, uid, { startDate, endDate, transactionId, currentTime, noOfDays, totalPricePaid, paymentMethod, totalPerDayCost, tokens }, order_status, subTotal, gst, deliveryCharge, JSON.stringify(userdata)]
//         );
  
//         const setupMeals = result.rows[0];
  
//         if (setupMeals.subscription_details.noOfDays === 0) {
//           res.json({ status: true, message: "Subscription ended", setupMeals });
//         } else if (result.rows.length === 0) {
//           res.status(400).json({ status: false, message: "Order ID already exists" });
//         } else {
//           res.json({ status: true, message: "Order Successfully Completed", setupMeals });
//         }
//       } catch (error) {
//         console.log("Error creating or updating setupmeals:", error);
//         res.status(500).json({ status: false, error: "Internal Server Error" });
//       }
//     } catch (error) {
//       console.log("Error creating pool:", error);
//       res.status(500).json({ status: false, error: "Internal Server Error" });
//     }
//   });
  
  
  
  
//   // Change order startus 
//   router.put("/updateOrderStatus/:orderId", async (req, res) => {
//     const orderId = req.params.orderId;
//     const { orderStatus } = req.body;
  
//     if (![2, 4, 6].includes(orderStatus)) {
//       return res.status(400).json({ status: false, message: "Invalid orderStatus value" });
//     }
  
//     try {
//       const tempPool = getDatabasePool();
  
//       const updateOrderStatusQuery = `
//         UPDATE setupmeals 
//         SET order_status = $1
//         WHERE orderId = $2
//         RETURNING *;
//       `;
  
//       const result = await tempPool.query(updateOrderStatusQuery, [orderStatus, orderId]);
  
//       if (result.rows.length === 0) {
//         return res.status(404).json({ status: false, message: "No setupmeals found with the provided orderId" });
//       }
  
//       const updatedSetupMeal = result.rows[0];
//       return res.json({ status: true, message: "Order status updated successfully", setupMeal: updatedSetupMeal });
//     } catch (error) {
//       console.log("Error updating order status:", error);
//       return res.status(500).json({ status: false, error: "Internal Server Error" });
//     }
//   });
  
  
  
  
//   // Get meals dashboard
//   router.get('/createSetupMeals', async (req, res) => {
//     const tempPool = getDatabasePool();
  
//     const getSetupMealsQuery = 'SELECT * FROM setupmeals';
  
//     try {
//       const result = await tempPool.query(getSetupMealsQuery);
//       res.json(result.rows);
//     } catch (error) {
//       console.error('Error retrieving setupmeals data:', error);
//       res.status(500).json({ error: 'Internal Server Error' });
//     } finally {
//       await tempPool.end();
//     }
//   });
  
  
//   router.post('/orders', async (req, res) => {
//     const tempPool = getDatabasePool();
//     const { orderId } = req.body;
  
//     try {
//       const query = `
//         SELECT * FROM setupmeals
//         WHERE orderId = $1
//       `;
//       const result = await tempPool.query(query, [orderId]);
//       res.json(result.rows);
//     } catch (error) {
//       console.error('Error fetching orders:', error);
//       res.status(500).json({ error: 'Internal server error' });
//     }
//   });
  
  
//   router.post('/getsetupmeals', async (req, res) => {
//     const { uid } = req.body;
//     const tempPool = getDatabasePool();
//     if (!uid) {
//       return res.status(400).json({ error: 'UID is required' });
//     }
  
//     try {
//       const query = {
//         text: 'SELECT * FROM setupmeals WHERE uid = $1',
//         values: [uid],
//       };
  
//       const result = await tempPool.query(query);
  
//       // Send the fetched data as response
//       res.json(result.rows);
//     } catch (error) {
//       console.error('Error fetching setupmeals data:', error);
//       res.status(500).json({ error: 'Internal server error' });
//     }
//   });



//   router.put('/updateSubscriptionDetails/:orderId', async (req, res) => {
//     const tempPool = getDatabasePool();
//     const { orderId } = req.params;
//     const { 
//       dinnerDelivery, 
//       breakfastReview, 
//       breakfastDelivery, 
//       lunchReview, 
//       dinnerReview, 
//       lunchDelivery 
//     } = req.body;
  
//     try {
//       const updateQuery = `
//         UPDATE setupmeals 
//         SET subscription_details = jsonb_set(
//           jsonb_set(
//             jsonb_set(
//               jsonb_set(
//                 jsonb_set(
//                   jsonb_set(
//                     subscription_details::jsonb,
//                     '{tokens, 0, dinnerDelivery}',
//                     $1::jsonb
//                   ),
//                   '{tokens, 0, breakfastReview}',
//                   $2::jsonb
//                 ),
//                 '{tokens, 0, breakfastDelivery}',
//                 $3::jsonb
//               ),
//               '{tokens, 0, lunchReview}',
//               $4::jsonb
//             ),
//             '{tokens, 0, dinnerReview}',
//             $5::jsonb
//           ),
//           '{tokens, 0, lunchDelivery}',
//           $6::jsonb
//         )
//         WHERE orderId = $7
//         RETURNING subscription_details;
//       `;
  
//       const { rows } = await tempPool.query(updateQuery, [
//         dinnerDelivery,
//         breakfastReview,
//         breakfastDelivery,
//         lunchReview,
//         dinnerReview,
//         lunchDelivery,
//         orderId
//       ]);
  
//       const updatedSubscriptionDetails = rows[0].subscription_details;
  
//       res.status(200).json({
//         "status": "success",
//         "message": "Subscription details updated successfully",
//         "subscription_details": updatedSubscriptionDetails
//       });
//     } catch (error) {
//       console.error('Error updating subscription details:', error);
//       res.status(500).json({
//         "status": "error",
//         "message": "Internal Server Error"
//       });
//     }
//   });
  
//   module.exports = router;
  
